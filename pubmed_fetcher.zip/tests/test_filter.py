
from pubmed_fetcher.filter import is_non_academic

def test_is_non_academic():
    assert is_non_academic("Pfizer Inc") == True
    assert is_non_academic("University of Oxford") == False
    assert is_non_academic("Moderna Biotech Ltd") == True
