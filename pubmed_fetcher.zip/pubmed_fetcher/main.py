
from pubmed_fetcher.fetch import fetch_pubmed_ids, fetch_paper_details
from pubmed_fetcher.filter import is_non_academic
from pubmed_fetcher.utils import extract_email
from typing import List, Dict
import xml.etree.ElementTree as ET

def get_filtered_papers(query: str, debug: bool = False) -> List[Dict]:
    ids = fetch_pubmed_ids(query)
    results = []

    for pid in ids:
        detail = fetch_paper_details(pid)
        root = ET.fromstring(detail["xml"])
        article = root.find(".//Article")
        if article is None:
            continue

        title_elem = article.find("ArticleTitle")
        title = title_elem.text if title_elem is not None else "N/A"

        pub_date_elem = root.find(".//PubDate")
        pub_date = pub_date_elem.findtext("Year") if pub_date_elem is not None else "N/A"

        non_academic_authors = []
        companies = []
        email = ""

        for author in root.findall(".//Author"):
            affil_elem = author.find("AffiliationInfo/Affiliation")
            if affil_elem is not None:
                affil_text = affil_elem.text
                if is_non_academic(affil_text):
                    name_parts = [author.findtext("ForeName", ""), author.findtext("LastName", "")]
                    name = " ".join(filter(None, name_parts))
                    non_academic_authors.append(name)
                    companies.append(affil_text)
                    if not email:
                        email = extract_email(affil_text)

        if non_academic_authors:
            results.append({
                "PubmedID": pid,
                "Title": title,
                "Publication Date": pub_date,
                "Non-academic Author(s)": "; ".join(non_academic_authors),
                "Company Affiliation(s)": "; ".join(set(companies)),
                "Corresponding Author Email": email
            })

        if debug:
            print(f"[DEBUG] Processed paper {pid}")

    return results
